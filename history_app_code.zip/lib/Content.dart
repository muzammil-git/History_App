import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Content extends StatelessWidget {

  static const String id = "Content";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/images/contentBackground.png")
          )
        ),
        // color: Colors.green,
        child: Column(

          children: [

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 80),
              child: Text('Content', style: TextStyle(fontSize: 30, fontFamily: "Bold",letterSpacing: 1),),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ContentButton('History'),
                SizedBox(width: 50,),
                ContentButton("Heroes")

              ],
            ),
            SizedBox(height: 25,),
            // SizedBox(height: 40,),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ContentButton('Geography'),
                SizedBox(width: 199,),
                ContentButton('Provinces \n& Cities')
              ],
            ),
            SizedBox(height: 30,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ContentButton('Languages\n & Dresses'),
                SizedBox(width: 50,),
                ContentButton('Food \n&\n Music')
              ],
            ),

          ],
        ),
      ),
    );
  }
}

class ContentButton extends StatelessWidget {
  
  ContentButton(this.name);
  final String name;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

      onTap: (){
        Navigator.pushNamed(context, '/Quiz1');
        print('Hello');
        },
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.lightGreen),
          color: Colors.green[200]
        ),
        child: Center(child: Text("$name",maxLines: 3, textAlign: TextAlign.center ,style: TextStyle(fontFamily: "Regular" ,fontWeight: FontWeight.bold,fontSize: 15, letterSpacing: 1.2,),)),
      ),
    );
  }
}
